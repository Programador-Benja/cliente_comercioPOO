from setuptools import setup

setup(
    name = "paquete",
    version = "1.0",
    description = "Este es el paquete distribuido de la segunda pre entrega",
    author = "Benjamin Lazarte",
    author_email = "benjaminlazarte123@gmail.com",
    packages=["paquete"]
)